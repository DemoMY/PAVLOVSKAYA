
import { GoogleGenAI } from "@google/genai";

// Initialize Gemini Client
const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const fetchVillageStatus = async (): Promise<{ text: string; sources: Array<{ title: string; uri: string }> }> => {
  if (!apiKey) {
    throw new Error("API Key is missing");
  }

  try {
    const model = 'gemini-2.5-flash';
    const prompt = `
      Найди самые свежие новости, объявления ЖКХ и экстренные предупреждения для станицы Павловская (Краснодарский край).
      
      Приоритет мониторинга (по убыванию важности):
      1. ГАЗ: утечки, плановые работы, отключения (Газпром газораспределение).
      2. СВЕТ И ВОДА: аварии, графики отключений (Россети, Водоканал).
      3. ДОРОГИ: перекрытия, серьезные ДТП.
      4. ПОГОДА: штормовые предупреждения.
      
      Если критических проблем нет, напиши краткую справку: "Системы жизнеобеспечения станицы работают в штатном режиме. Погода: [кратко]."
      
      Тон: Оперативный дежурный. Кратко, четко, без воды. Используй статусные эмодзи (✅, ⚠️, 🚨).
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        systemInstruction: "Ты - центр мониторинга жизнедеятельности станицы. Твоя задача - спокойствие и информированность жителей.",
      },
    });

    const text = response.text || "Нет данных.";
    
    // Extract grounding metadata safely
    const sources: Array<{ title: string; uri: string }> = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;

    if (chunks) {
      chunks.forEach((chunk) => {
        if (chunk.web) {
          sources.push({
            title: chunk.web.title || "Источник",
            uri: chunk.web.uri || "#"
          });
        }
      });
    }

    return { text, sources };
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Не удалось загрузить сводку. Проверьте соединение.");
  }
};

export const fetchVillageEvents = async (): Promise<any[]> => {
  if (!apiKey) return [];

  try {
    const prompt = `
      Найди актуальные мероприятия в станице Павловская (Краснодарский край) на ближайшие дни.
      Ищи везде: 
      1. ДК (Дворец Культуры) и Кинотеатр - сеансы.
      2. Центральная Площадь - праздники, ярмарки, гуляния.
      3. Парк - мероприятия для детей.
      4. Спорт (Стадион, ФОК) - матчи, соревнования.
      
      Верни ТОЛЬКО валидный JSON массив объектов (без markdown форматирования):
      [
        {
          "id": "string",
          "title": "Название",
          "date": "День и время",
          "place": "Место (например: Площадь, ДК, Парк)",
          "price": "Цена (или 'Бесплатно')",
          "type": "Кино" | "Спорт" | "Праздник" | "Детям" | "Другое",
          "imageUrl": "ссылка на картинку",
          "contact": "телефон кассы или ссылка на сайт",
          "actionType": "call" | "link" | "none",
          "actionLabel": "Купить билет" или "Позвонить"
        }
      ]
      Если точных данных нет, сгенерируй 4-5 реалистичных события. 
      Обязательно добавь контакты (например сайт кинотеатра или телефон ДК).
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      }
    });

    let text = response.text;
    if (!text) return [];
    
    // Clean up potential markdown code blocks (```json ... ```)
    text = text.replace(/```json/g, '').replace(/```/g, '').trim();
    
    try {
       return JSON.parse(text);
    } catch (e) {
       console.error("JSON parse error", e);
       console.log("Raw text:", text);
       return [];
    }

  } catch (error) {
    console.error("Events Fetch Error", error);
    return [];
  }
};

export const sendChatMessage = async (history: Array<{role: 'user' | 'model', parts: Array<{text: string}>}>, message: string): Promise<string> => {
  if (!apiKey) return "Ошибка ключа API";

  try {
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        tools: [{ googleSearch: {} }],
        systemInstruction: `Ты — умный помощник для жителей станицы Павловская (Краснодарский край). 
        Твоя цель — помогать людям находить информацию.
        
        Ты ОБЯЗАН использовать Google Search для поиска точных ответов на вопросы:
        - Телефоны служб и организаций.
        - График работы (МФЦ, Почта, Больница).
        - Адреса магазинов и аптек.
        - Расписание автобусов.
        
        Если спрашивают "Где поесть?" или "Куда сходить?" — ищи реальные отзывы и места в Павловской.
        Всегда общайся на русском языке. Будь вежлив и полезен.`,
      },
      history: history
    });

    const result = await chat.sendMessage({ message });
    
    let answer = result.text || "Извините, я не понял запрос.";

    // Append sources if available
    const chunks = result.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks && chunks.length > 0) {
      const links = chunks
        .filter(c => c.web?.uri && c.web?.title)
        .map(c => `• [${c.web?.title}](${c.web?.uri})`)
        .join('\n');
      
      if (links) {
        answer += `\n\n📚 Источники:\n${links}`;
      }
    }

    return answer;
  } catch (error) {
    console.error("Chat Error:", error);
    return "Сейчас я не могу ответить. Попробуйте позже.";
  }
};
