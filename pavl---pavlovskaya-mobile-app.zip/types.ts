
export enum AppTab {
  TAXI = 'TAXI',
  LIFE = 'LIFE',
  EVENTS = 'EVENTS',
  CHAT = 'CHAT'
}

export interface TaxiService {
  id: string;
  name: string;
  phone: string;
  description?: string;
  type: 'local' | 'app' | 'chat';
  url?: string; // Deep link or chat link
  brandColor?: string; // Specific brand color class
}

export interface VillageAlert {
  id: string;
  title: string;
  content: string;
  severity: 'critical' | 'warning' | 'info';
  date: string;
  sourceUrl?: string;
}

export interface EventItem {
  id: string;
  title: string;
  date: string;
  place: string;
  price: string;
  imageUrl: string;
  contact?: string; // Phone or URL
  actionType?: 'call' | 'link' | 'none';
  actionLabel?: string; // "Купить", "Позвонить"
}

export interface GeminiStatusState {
  loading: boolean;
  data: string | null;
  sources: Array<{ title: string; uri: string }>;
  error: string | null;
}
